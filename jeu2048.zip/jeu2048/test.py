def puissance2(n):
    puissance = 1
    while puissance < n:
        puissance *= 2
    return puissance == n

L = [0, 1, 2, 3, 4, 6, 7, 12, 16, 256, 2048, 2049]
M = [puissance2(L[i]) for i in range(len(L))]
print(M)