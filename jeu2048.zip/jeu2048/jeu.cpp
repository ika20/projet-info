#include "jeu.h"
#include <iomanip> // pour setw dans affichage.



/** Fonction qui donne le nombre de cases vides d'une grille de 2048
 * @param g une grille
 * @return le nombre de cases vides de cette grille
**/
int vides(const Grille &g){ 
  int compteur = 0;
  for(size_t i = 0; i < g.table.size(); i += 1){
    for(size_t j = 0; j < g.table.size(); j += 1){
      if(g.table.at(i).at(j) == 0){                 // Si la case est un 0
        compteur += 1;                              // On incrémente le compteur
      }
    }
  }

  return compteur;
}



/** Fonction qui renvoie la proportion de tuiles 2 au tirage, exprimée par un entier entre 0 et 10
 * @param g une grille
 * @return la proportion pour cette grille
**/
int proportion(const Grille &g){ 
  return g.proportion;
}



/** Fonction qui renvoie le score à atteindre
 * @param g une grille
 * @return le score cible pour cette grille
**/
int cible(const Grille &g){ 
  return g.cible;
}



/** Fonction qui renvoie la dimension d'une grille de 2048
 * @param g une grille
 * @return la dimension de la grille
**/
int dimension(const Grille &g){ 
  return g.table.size();
}



/** Fonction qui renvoie le score actuel d'une grile de 2048
 * @param g une grille
 * @return le score de la grille
**/
int score(const Grille &g){ 
  return g.score;
}



/** Fonction qui indique si la valeur cible a ete atteinte
 * @param g une grille
 * @return true si la valeur cible a ete atteinte, false sinon
**/
bool succes(const Grille &g) { 
  for(size_t i = 0; i < g.table.size(); i += 1){
    for(size_t j = 0; j < g.table.at(i).size(); j += 1){
      if(g.table.at(i).at(j) == g.cible){
        return true;
      }
    }
  }

  return false;
}



/** Fonction qui initialise une grille passee par reference avec les parametres indiques et avec deux tuiles dont la valeur et la position sont generees aleatoirement
 * @param g une grille
 * @param dimension la dimension de la grille a initialiser
 * @param cible le score a atteindre pour cette grille
 * @param proportion la proportion de tuiles 2 au tirage pour cette grille
 * @return true si l'initialisation a ete possible, false sinon
*/
bool init(Grille &g, int dimension, int cible, int proportion) {
  if(not(puissance2(cible))){
    cerr << "Erreur : la cible doit etre une puissance de 2 strictement superieure a 1" << endl;
    return false;
  }

  if(proportion < 0 or proportion > 10){
    cerr << "Erreur : la proportion doit etre un entier compris entre 0 et 10" << endl;
    return false;
  }

  if(dimension < 4){
    cerr << "Erreur : dimension insuffisente" << endl;
    return false;
  }

  g.table.clear(); // On vide la grille au cas ou elle ait deja ete utilisee

  g.cible = cible;
  g.proportion = proportion;
  g.score = 0;

  vector<int> ligne(dimension, 0);  // On cree une ligne de 0
  for(int i = 0; i < dimension; i += 1){
    g.table.push_back(ligne);       // On ajoute cette ligne autant de fois que necessaire pour que la grille ait la dimension choisie
  }
  
  int tuile1 = nouvelle(g);         // Creation de deux nouvelles tuiles avec une probabilite de proportion/10 que ce soit un 2
  int tuile2 = nouvelle(g);         // et une probabilite de (1 - proportion)/10 que ce soit un 4

  int place1 = place(g);            // Generation de la position des deux nouvelle tuiles
  int place2 = place(g);
  while(place1 == place2){          // Si la position de la deuxieme tuile est identique a celle de la premiere, on en genere
    place2 = place(g);              // une nouvelle jusqu'a ce qu'elles soient differentes
  }
  
  g.table.at((place1-1)/dimension).at((place1-1)%dimension) = tuile1; // Ajout de ces deux tuile a leur positions respectives generee precedemment
  g.table.at((place2-1)/dimension).at((place2-1)%dimension) = tuile2;

  return true;
}



/** Fonction qui initialise une grille a partir d'un vecteur passe en parametres
 * @param g une grille
 * @param v vecteur a partir duquel la grille doit etre construite
 * @param cible le score a atteindre pour cette grille
 * @param proportion la proportion de tuiles 2 au tirage pour cette grille
 * @return true si l'initialisation a ete possible, false sinon
**/
bool charge(Grille &g, vector<vector<int>> &v, int cible, int proportion) {
  size_t dim = v.size(); 
  if (dim < 4) {
    cerr << "Erreur : nombre de lignes insuffisant: " << dim << endl;
    return false;
  }
  
  if(not(puissance2(cible))){
    cerr << "Erreur : la cible doit etre une puissance de 2 strictement superieure a 1";
    return false;
  }

  if(proportion < 0 or proportion > 10){
    cerr << "Erreur : la proportion doit etre un entier compris entre 0 et 10";
    return false;
  }

  vector<int> tailles_lignes; // Verification que la grille fournie est bien carree
  for(size_t t = 0; t < v.size(); t += 1){
    tailles_lignes.push_back(v.at(t).size()); // On cree un vecteur avec les tailles de toutes les lignes
  }
  for(size_t i1 = 0; i1 < tailles_lignes.size(); i1 += 1){
    for(size_t i2 = i1+1; i2 < tailles_lignes.size(); i2 += 1){
      if(tailles_lignes.at(i1) != tailles_lignes.at(i2)){ // On verifie que tous les elements de tailles_lignes sont egaux, c'est-a-dire que toutes les lignes font la meme taille
        cerr << "Erreur : les lignes doivent toutes faire la meme taille, sinon ce n'est pas une grille carree." << endl;
        return false;
      }
    }
  }
  if(tailles_lignes.at(0) != v.size()){ // On verifie que le nombre de lignes est bien egal au nombre de colonnes
    cerr << "Erreur : la grille doit contenir autant de lignes que de colonnes pour avoir une grille carree. Or, ici il y a " << v.size() << " lignes et " << tailles_lignes.at(0) << " colonnes." << endl;
    return false;
  }

  for(size_t p1 = 0; p1 < v.size(); p1 += 1){ // Verification que la grille fournie ne contient que des puissances de 2
    for(size_t p2 = 0; p2 < v.size(); p2 += 1){
      if(v.at(p1).at(p2) != 0){
        bool puissance = puissance2(v.at(p1).at(p2));
        if(not(puissance)){  // On verifie que le nombre a la (p1+1)e ligne et la (p2+1)e colonne est bien une puissance de 2
          cerr << "Erreur : la grille ne doit contenir que des puissances de 2. Or, a la " << p1+1 <<"e ligne et " << p2+1 << "e colonne, il y a un " << v.at(p1).at(p2) << "." << endl;
          return false;
        }
      }
    }
  }

  g.cible = cible;
  g.proportion = proportion;
  g.score = 0;

  g.table.clear();  // On vide la grille au cas ou elle ait deja ete utilisee

  for(size_t i = 0; i < v.size(); i += 1){  // Remplissage de la grille a partir de v
    vector<int> ligne;
    for(size_t j = 0; j < v.at(i).size(); j += 1){
      ligne.push_back(v.at(i).at(j));   // On remplit une ligne avec la i-eme ligne de v
    }
    g.table.push_back(ligne);           // On ajoute cette ligne a notre grille
  }

  return true;
}



/** Fonction qui effectue le déplacement vers la droite de la grille
 * @param g une grille
 * @return le nombre de cases vides de la grille apres le deplacement si le deplacement a ete possible, et -1 sinon
**/
int droite(Grille &g){
  vector<vector<int>> grille_depart = g.table;

  for(size_t i = 0; i < g.table.size(); i += 1){
    vector<int> ligne = g.table.at(i);        // Puisque le mouvement s'effectue horizontalement, on cree un vecteur pour la ligne courante afin de simplifier l'ecriture

    int k = ligne.size()-2;                   // Indice qui va parcourir la ligne de droite a gauche
    int m = -1;                               // Indice qui va servir a marquer la derniere case qui a ete fusionnee afin de ne pas la fusionner une deuxieme fois
    while(k >= 0){                            
      if(ligne.at(k) != 0){                   // Si la case n'est pas vide, on regarde la valeur de celle a sa droite
        if(ligne.at(k+1) != 0){               // Si la case a sa droite n'est pas vide et qu'elles ont la meme valeur, on les fusionne
          if(ligne.at(k+1) == ligne.at(k)){
            ligne.at(k+1) = ligne.at(k+1)*2;
            ligne.at(k) = 0;
            m = k+1;
            g.score += ligne.at(k+1);
          }
        }
        else if(ligne.at(k+1) == 0){            // Si la case a sa droite est vide, on cherche la case vide la plus loin
          int l = k+1;                          // a sa droite et on echange notre case et cette case vide
          while(l < ligne.size() and ligne.at(l) == 0){
            l += 1;
          }

          ligne.at(l-1) = ligne.at(k);
          ligne.at(k) = 0;

          if(l >= ligne.size()){                // Si on a deborde de la ligne, la case vide la plus eloignee a droite 
            l -= 1;                             // est la derniere case de la ligne
          }

          if(ligne.at(l) == ligne.at(l-1) and l != m){  // Si la case a droite de notre case qui vient d'etre deplacee
            ligne.at(l) = ligne.at(l)*2;                // est egale a notre case et qu'elle n'a pas deja ete fusionnee, 
            ligne.at(l-1) = 0;                          // on les fusionne
            m = l;
            g.score += ligne.at(l);
          }
        }
      }
      
      k -= 1; // On passe a la case suivante
    }

    g.table.at(i) = ligne;
  }

  bool egaux = true;  
  for(size_t a = 0; a < g.table.size(); a += 1){          // On verifie si le mouvement a bien eu lieu ou non en regardant si la grille 
    for(size_t b = 0; b < g.table.at(a).size(); b += 1){  // apres le deplacement est la meme que la grille initiale
      if(grille_depart.at(a).at(b) != g.table.at(a).at(b)){
        egaux = false;
      }
    }
  }

  if(egaux){
    return -1;
  }

  if(vides(g) >= 1 and not(egaux)){   // Ajout d'une case de valeur et d'emplacement aleatoires
    int tuile = nouvelle(g);
    int plc = place(g);
    int x = 0;                        // Indices pour parcourir les cases de la grille
    int y = 0;
    int compteur = 0;

    if(g.table.at(y).at(x) == 0){
      compteur += 1;
    }

    while(compteur < plc){
      if(x == g.table.size()-1){      // On se deplace a la prochaine case, et si elle est vide on ajoute 1 au compteur
        x = 0;
        y += 1;
      }
      else{
        x += 1;
      }

      if(g.table.at(y).at(x) == 0){
        compteur += 1;
      }
    }

    g.table.at(y).at(x) = tuile;      // Lorsqu'on a atteint la case vide a la place desiree, on la remplace par sa nouvelle valeur
  }

  return vides(g); 
}



/** Fonction qui effectue le déplacement vers la gauche de la grille
 * @param g une grille
 * @return le nombre de cases vides de la grille apres le deplacement si le deplacement a ete possible, et -1 sinon
**/
int gauche(Grille &g){
  vector<vector<int>> grille_depart = g.table;

  for(size_t i = 0; i < g.table.size(); i += 1){
    vector<int> ligne = g.table.at(i);        // Puisque le mouvement s'effectue horizontalement, on cree un vecteur pour la ligne courante afin de simplifier l'ecriture

    size_t k = 1;                             // Indice qui va parcourir la ligne de gauche a droite
    int m = -1;                               // Indice qui va servir a marquer la derniere case qui a ete fusionnee afin de ne pas la fusionner une deuxieme fois
    while(k <= ligne.size()-1){
      if(ligne.at(k) != 0){                   // Si la case n'est pas vide, on regarde la valeur de celle a sa gauche
        if(ligne.at(k-1) != 0){               // Si la case a sa gauche n'est pas vide et qu'elles ont la meme valeur, on les fusionne
          if(ligne.at(k-1) == ligne.at(k)){
            ligne.at(k-1) = ligne.at(k-1)*2;
            ligne.at(k) = 0;
            m = k-1;
            g.score += ligne.at(k-1);
          }
        }
        else if(ligne.at(k-1) == 0){        // Si la case a sa gauche est vide, on cherche la case vide la plus loin
          int l = k-1;                      // a sa gauche et on echange notre case et cette case vide
          while(l >= 0 and ligne.at(l) == 0){
            l -= 1;
          }

          ligne.at(l+1) = ligne.at(k);
          ligne.at(k) = 0;

          if(l < 0){                        // Si on a deborde de la ligne, la case vide la plus eloignee a gauche 
            l += 1;                         // est la premiere case de la ligne
          }

          if(ligne.at(l) == ligne.at(l+1) and l != m){  // Si la case a droite de notre case qui vient d'etre deplacee
            ligne.at(l) = ligne.at(l)*2;                // est egale a notre case et qu'elle n'a pas deja ete fusionnee, 
            ligne.at(l+1) = 0;                          // on les fusionne
            m = l;
            g.score += ligne.at(l);
          }
        }
      }

      k += 1; // On passe a la case suivante
    }

    g.table.at(i) = ligne;
  }

  bool egaux = true;
  for(size_t a = 0; a < g.table.size(); a += 1){          // On verifie si le mouvement a bien eu lieu ou non en regardant si la grille 
    for(size_t b = 0; b < g.table.at(a).size(); b += 1){  // apres le deplacement est la meme que la grille initiale
      if(grille_depart.at(a).at(b) != g.table.at(a).at(b)){
        egaux = false;
      }
    }
  }

  if(egaux){
    return -1;
  }

  if(vides(g) >= 1 and not(egaux)){   // Ajout d'une case de valeur et d'emplacement aleatoires
    int tuile = nouvelle(g);
    int plc = place(g);
    int x = 0;                        // Indices pour parcourir les cases de la grille
    int y = 0;
    int compteur = 0;

    if(g.table.at(y).at(x) == 0){
      compteur += 1;
    }

    while(compteur < plc){
      if(x == g.table.size()-1){      // On se deplace a la prochaine case, et si elle est vide on ajoute 1 au compteur
        x = 0;
        y += 1;
      }
      else{
        x += 1;
      }

      if(g.table.at(y).at(x) == 0){
        compteur += 1;
      }
    }

    g.table.at(y).at(x) = tuile;      // Lorsqu'on a atteint la case vide a la place desiree, on la remplace par sa nouvelle valeur
  }

  return vides(g); 
}



/** Fonction qui effectue le déplacement vers le haut de la grille
 * @param g une grille
 * @return le nombre de cases vides de la grille apres le deplacement si le deplacement a ete possible, et -1 sinon
**/
int haut(Grille &g){
  vector<vector<int>> grille_depart = g.table;

  for(size_t  i = 0; i < g.table.size(); i += 1){
    size_t k = 1;                               // Indice qui va parcourir chaque colonne de haut en bas
    int m = -1;                                 // Indice qui va servir a marquer la derniere case qui a ete fusionnee afin de ne pas la fusionner une deuxieme fois
    while(k <= g.table.size()-1){
      if(g.table.at(k).at(i) != 0){             // Si la case n'est pas vide, on regarde la valeur de celle en haut
        if(g.table.at(k-1).at(i) != 0){         // Si la case du dessus n'est pas vide et qu'elles ont la meme valeur, on les fusionne
          if(g.table.at(k-1).at(i) == g.table.at(k).at(i)){
            g.table.at(k-1).at(i) = g.table.at(k-1).at(i)*2;
            g.table.at(k).at(i) = 0;
            m = k-1;
            g.score += g.table.at(k-1).at(i);
          }
        }
        else if(g.table.at(k-1).at(i) == 0){    // Si la case en haut est vide, on cherche la case vide la plus loin
          int l = k-1;                          // au dessus et on echange notre case et cette case vide
          while(l >= 0 and g.table.at(l).at(i) == 0){
            l -= 1;
          }
          g.table.at(l+1).at(i) = g.table.at(k).at(i);
          g.table.at(k).at(i) = 0;

          if(l < 0){                            // Si on a deborde de la colonne, la case vide la plus eloignee au dessus 
            l += 1;                             // est la premiere case de la colonne
          }

          if(g.table.at(l).at(i) == g.table.at(l+1).at(i) and m != l){  // Si la case au dessus de notre case qui vient d'etre deplacee
            g.table.at(l).at(i) = g.table.at(l).at(i)*2;                // est egale a notre case et qu'elle n'a pas deja ete fusionnee, 
            g.table.at(l+1).at(i) = 0;                                  // on les fusionne
            m = l;
            g.score += g.table.at(l).at(i);
          }
        }
      }

      k += 1;  // On passe a la case suivante
    }
  }

  bool egaux = true;
  for(size_t a = 0; a < g.table.size(); a += 1){          // On verifie si le mouvement a bien eu lieu ou non en regardant si la grille 
    for(size_t b = 0; b < g.table.at(a).size(); b += 1){  // apres le deplacement est la meme que la grille initiale
      if(grille_depart.at(a).at(b) != g.table.at(a).at(b)){
        egaux = false;
      }
    }
  }

  if(egaux){
    return -1;
  }


  if(vides(g) >= 1 and not(egaux)){   // Ajout d'une case de valeur et d'emplacement aleatoires
    int tuile = nouvelle(g);
    int plc = place(g);
    int x = 0;                        // Indices pour parcourir les cases de la grille
    int y = 0;
    int compteur = 0;

    if(g.table.at(y).at(x) == 0){
      compteur += 1;
    }

    while(compteur < plc){
      if(x == g.table.size()-1){      // On se deplace a la prochaine case, et si elle est vide on ajoute 1 au compteur
        x = 0;
        y += 1;
      }
      else{
        x += 1;
      }

      if(g.table.at(y).at(x) == 0){
        compteur += 1;
      }
    }

    g.table.at(y).at(x) = tuile;      // Lorsqu'on a atteint la case vide a la place desiree, on la remplace par sa nouvelle valeur
  }

  return vides(g); 
}



/** Fonction qui effectue le déplacement vers le bas de la grille
 * @param g une grille
 * @return le nombre de cases vides de la grille apres le deplacement si le deplacement a ete possible, et -1 sinon
**/
int bas(Grille &g){ 
  vector<vector<int>> grille_depart = g.table;

  for(size_t i = 0; i < g.table.size(); i += 1){
    int k = g.table.size()-2;                 // Indice qui va parcourir chaque colonne de bas en haut
    int m = -1;                               // Indice qui va servir a marquer la derniere case qui a ete fusionnee afin de ne pas la fusionner une deuxieme fois
    while(k >= 0){
      if(g.table.at(k).at(i) != 0){           // Si la case n'est pas vide, on regarde la valeur de celle en dessous
        if(g.table.at(k+1).at(i) != 0){       // Si la case du dessous n'est pas vide et qu'elles ont la meme valeur, on les fusionne
          if(g.table.at(k+1).at(i) == g.table.at(k).at(i)){
            g.table.at(k+1).at(i) = g.table.at(k+1).at(i)*2;
            g.table.at(k).at(i) = 0;
            m = k+1;
            g.score += g.table.at(k+1).at(i);
          }
        }
        else if(g.table.at(k+1).at(i) == 0){  // Si la du dessous est vide, on cherche la case vide la plus loin
          int l = k+1;                        // en bas et on echange notre case et cette case vide
          while(l < g.table.size() and g.table.at(l).at(i) == 0){
            l += 1;
          }

          g.table.at(l-1).at(i) = g.table.at(k).at(i);
          g.table.at(k).at(i) = 0;

          if(l >= g.table.size()){            // Si on a deborde de la colonne, la case vide la plus eloignee en bas
            l -= 1;                           // est la derniere case de la colonne
          }

          if(g.table.at(l).at(i) == g.table.at(l-1).at(i) and l != m){  // Si la case en dessous de notre case qui vient d'etre deplacee
            g.table.at(l).at(i) = g.table.at(l).at(i)*2;                // est egale a notre case et qu'elle n'a pas deja ete fusionnee, 
            g.table.at(l-1).at(i) = 0;                                  // on les fusionne
            m = l;
            g.score += g.table.at(l).at(i);
          }
        }
      }

      k -= 1;  // On passe a la case suivante
    }
  }

  bool egaux = true;  
  for(size_t a = 0; a < g.table.size(); a += 1){            // On verifie si le mouvement a bien eu lieu ou non en regardant si la grille 
    for(size_t b = 0; b < g.table.at(a).size(); b += 1){    // apres le deplacement est la meme que la grille initiale
      if(grille_depart.at(a).at(b) != g.table.at(a).at(b)){
        egaux = false;
      }
    }
  }

  if(egaux){
    return -1;
  }

  if(vides(g) >= 1 and not(egaux)){   // Ajout d'une case de valeur et d'emplacement aleatoires
    int tuile = nouvelle(g);
    int plc = place(g);
    int x = 0;                        // Indices pour parcourir les cases de la grille
    int y = 0;
    int compteur = 0;

    if(g.table.at(y).at(x) == 0){
      compteur += 1;
    }

    while(compteur < plc){
      if(x == g.table.size()-1){      // On se deplace a la prochaine case, et si elle est vide on ajoute 1 au compteur
        x = 0;
        y += 1;
      }
      else{
        x += 1;
      }

      if(g.table.at(y).at(x) == 0){
        compteur += 1;
      }
    }

    g.table.at(y).at(x) = tuile;      // Lorsqu'on a atteint la case vide a la place desiree, on la remplace par sa nouvelle valeur
  }

  return vides(g); 
}



void menu() {
  bool rejouer = true;
  bool jouer;
  string joue;
  cout << "BIENVENUE SUR LE JEU 2048 !" << endl << endl;
  do{
    cout << "Entrez j pour jouer ";
    cin >> joue;
    cout << endl << endl;
    jouer = joue=="j";
    Grille g;
    string mode;

  
    if(jouer){
      cout << endl;
      cout << "--------------------------------------------MODES-------------------------------------------" << endl;
      cout << "| - c : mode classique : grille 4x4, score                                                  |" << endl;
      cout << "|        > grille 4x4                                                                       |" << endl;
      cout << "|        > score a atteindre : 2048                                                         |" << endl;
      cout << "|        > probabilite d'avoir un 2 pour une nouvelle tuile : 9/10                          |" << endl;
      cout << "|                                                                                           |" << endl;
      cout << "| - p : mode personnalise :                                                                 |" << endl;
      cout << "|        > grille de dimension au choix entre 4x4 et 10x10                                  |" << endl;
      cout << "|        > score a atteindre : personnalise                                                 |" << endl;
      cout << "|        > probabilite d'avoir un 2 pour une nouvelle tuille : au choix entre 0 et 10       |" << endl;
      cout << "|                                                                                           |" << endl;
      cout << "| - r : mode aleatoire                                                                      |" << endl;
      cout << "|        > grille de dimension aleaatoire entre 4x4 et 10x10                                |" << endl;
      cout << "|        > score a atteindre : aleatoire entre 128 et 2048                                  |" << endl;
      cout << "|        > probabilite d'avoir un 2 pour une nouvelle tuille : aleatoire entre 0 et 10      |" << endl;
      cout << "|                                                                                           |" << endl;
      cout << "| - g : mode creation de grille                                                             |" << endl;
      cout << "--------------------------------------------------------------------------------------------" << endl << endl;
      cout << "Choissez un mode de jeu : ";
      cin >> mode;
      if(mode != "c" and mode != "p" and mode != "r" and mode != "g"){
        do{
          cout << "Veuillez saisir un mode existant : ";
          cin >> mode;
        }while(mode != "c" and mode != "p" and mode != "r" and mode != "g");
      }
      cout << endl << "-------------Creation de la partie-------------" << endl;
      if(mode == "c"){
        init(g, 4, 2048, 9);
      }
      else if(mode == "p"){
        int dimension;
        int cible;
        int proportion;
        cout << "Saisissez les informations suivantes :" << endl;
        cout << "> dimension de la grille : ";
        cin >> dimension;
        if(dimension < 4 or dimension > 10){
          do{
            cout << "Erreur : la dimension de la grille doit etre comprise entre 4 et 10. Saisissez a nouveau une dimension : ";
            cin >> dimension;
          }while(dimension < 4 or dimension > 10);
        }
        cout << "> valeur cible : ";
        cin >> cible;
        if(not(puissance2(cible))){
          do{
            cout << "Erreur : la cible doit etre une puissance de 2 strictement superieure a 1. Saisissez a nouveau une cible : ";
            cin >> cible;
          }while(not(puissance2(cible)));
        }

        cout << "> proportion de 2 pour les nouvelles tuiles : ";
        cin >> proportion;
        if(proportion < 0 or proportion > 10){
          do{
            cout << "Erreur : la proportion de 2 doit etre comprise entre 0 et 10. Saisissez a nouveau une proportion : ";
            cin >> proportion;
          }while(proportion < 0 or proportion > 10);
        }
        init(g, dimension, cible, proportion);
      }
      else if(mode == "r"){
        int dimension = rand() %7 + 4;
        int cible = rand() %5;
        if(cible == 0){
          cible = 128;
        }
        else if(cible == 1){
          cible = 256;
        }
        else if(cible == 2){
          cible = 512;
        }
        else if(cible == 3){
          cible = 1024;
        }
        else if(cible == 4){
          cible = 2048;
        }
        int proportion = rand() %11;
        init(g, dimension, cible, proportion);
      }
      else if(mode == "g"){
        int dimension;
        cout << "> saisisez la dimension de la grille a creer (entre 4 et 10): ";
        cin >> dimension;
        if(dimension < 4 or dimension > 10){
          do{
            cout << "Erreur : la dimension doit etre comprise entre 4 et 10. Saisisez a nouveau une dimension : ";
            cin >> dimension;
          }while(dimension < 4 or dimension > 10);
        }
        cout << endl;
        vector<int> ligne(dimension);
        vector<vector<int>> v;
        for(int d=0; d<dimension; d+=1){
          v.push_back(ligne);
        }

        int valeur;
        for(int i=0; i<dimension; i+= 1){
          for(int j=0; j<dimension; j+=1){
            cout << "> saisissez la valeur de la tuile a la " << i+1 << "e ligne et la " << j+1 << "e colonne (0 pour une case vide) : ";
            cin >> valeur;
            bool p2;
            do{
              p2 = puissance2(valeur);
              if(valeur != 0 and not(p2)){
                cout << "Erreur : les valeurs saisies doivent etre des puissances de 2. Saisissez a nouveau une valeur : ";
                cin >> valeur;
              }
              else if(valeur == 0){
                p2 = true;
              }
            }while(not p2);
            v.at(i).at(j) = valeur;
          }
        }
        int cible;
        cout << endl << "> saisisez le score cible pour cette partie : ";
        cin >> cible;
        if(not(puissance2(cible))){
          do{
            cout << "Erreur : la cible doit etre une puissance de 2 strictement superieure a 1. Saisissez a nouveau une cible : ";
            cin >> cible;
          }while(not(puissance2(cible)));
        }
        int proportion;
        cout << "> saisisez la proportion de 2 : ";
        cin >> proportion;
        if(proportion < 0 or proportion > 10){
          do{
            cout << "Erreur : la proportion de 2 doit etre comprise entre 0 et 10. Saisissez a nouveau une proportion : ";
            cin >> proportion;
          }while(proportion < 0 or proportion > 10);
        }
  
        charge(g, v, cible, proportion);
      }
      cout << "------------------------------------------------" << endl << endl;

      cout << "\t===== Grille de depart =====";
      affiche(g);
      cout << "> Valeur cible : " << g.cible << endl << endl;
      cout << endl;
      cout << "------COMMANDES------" << endl;
      cout << "| - i : haut         |" << endl;
      cout << "| - j : gauche       |" << endl;
      cout << "| - k : bas          |" << endl;
      cout << "| - l : droite       |" << endl;
      cout << "| - a : abandonner   |" << endl;
      cout << "---------------------" << endl;
      
      do{
        cout << endl << endl << "Entrez une commande : ";
        char action;
        cin >> action;
        cout << endl << endl;
        switch(action){
          case 'i': haut(g); affiche(g); break;
          case 'j': gauche(g); affiche(g); break;
          case 'k': bas(g); affiche(g); break;
          case 'l': droite(g); affiche(g); break;
          case 'a': 
            jouer=false; 
            char rejoue;
            cout << "Voulez vous rejouer ? Entrez r pour rejouer ";
            cin >> rejoue;
            rejouer = rejoue=='r';
            break;
          default : cerr << "Veuillez entrer une commande valide" << endl;
        }

        Grille test;
        charge(test, g.table, g.cible, g.proportion);
        if(succes(g)){
          jouer = false;
          string rejoue;
          // cout << endl << endl << "*~*~*~*~*~*~*~* BRAVO ! VOUS AVEZ ATTEINT " << g.cible << "! *~*~*~*~*~*~*~*" << endl << endl << endl;
          cout << endl << "*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*" << endl;
          cout << "\t\t BRAVO ! VOUS AVEZ ATTEINT " << g.cible << " !" << endl;
          cout << "*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*~*" << endl << endl;
          cout << "Voulez-vous rejouer ? Entrez r pour rejouer ";
          cin >> rejoue;
          rejouer = rejoue=="r";
        }
        else if(droite(test) == -1 and gauche(test)==-1 and haut(test)==-1 and bas(test)==-1){
          jouer = false;
          string rejoue;
          cout << "VOUS AVEZ PERDU !" << endl;
          cout << "Voulez-vous rejouer ? Entrez r pour rejouer ";
          cin >> rejoue;
          rejouer = rejoue=="r";
        }
      }while(jouer); 
    }
  }while(rejouer);
  

}



/** Fonction qui teste si un nombre est une puissance de 2 strictement superieure a 1
 * @param n un entier
 * @return true si n est une puissance de 2 strictement superieure a 1, et false sinon
**/
bool puissance2(int n){
  int puissance = 2;  
  while(puissance < n){
    puissance = puissance*2;
  }

  return puissance == n;
}


/*		 Pour les extensions éventuelles */
void sauve(const Grille &g, string filename) {

}


void restaure(Grille &g, string filename) {

}


/*
 * 		Fonctions mise à disposition. Pas de raison d'y toucher !
 *	Rappel: la fonction main() est dans le fichier test.cpp
 */	

void affiche (const Grille &g) {
  int i, j, k;
  int max = dimension(g);
  cout << endl << " \t ";
  for(k = 0; k < (6+1)*max-1; k = k+1) { cout << "-"; }
  cout << endl;
  /* Verifier si on veut que la ligne du haut soit 0 ou max-1 */
  for(i = 0; i < max; i = i+1) {
    cout << "\t|";
    for(j=0; j < max; j=j+1) {
      if(g.table.at(i).at(j) == 0) {
	cout << "      |";
      } else { cout << " " << setw(4) << g.table.at(i).at(j) << " |" ; }
    }
    if (i != max-1) {
      cout << endl << "\t|";
      for(k = 0; k < (6+1)*max-1; k = k+1) { cout << "-"; }
      cout << "|" << endl;
    } else {
      cout << endl << "\t ";
      for(k = 0; k < (6+1)*max-1; k = k+1) { cout << "-"; }
      cout << endl;
    }
  }
  cout << endl << "************************************" << endl;
  cout << "  Score : " << score(g) << "  |  Cases vides : " << vides(g) << "  " << endl;
  cout << "************************************" << endl;
}
